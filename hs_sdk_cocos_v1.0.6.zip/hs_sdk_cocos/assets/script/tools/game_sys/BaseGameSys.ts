import AdManager from "../ad/AdManager";
import { ad_native_type } from "../ad/hs_enum";
import OppoAd from "../ad/OppoAd";
import VIVOAd from "../ad/VIVOAd";
import Constant from "../const/Constant";
import { e_sdk_type, REWARD_TYPE, AUTO_AD_TYPE, PLATFORM } from "../enum/Enum";
import HttpManager from "../http/HttpManager";
import StringUtil from "../StringUtil";
import { TJ } from "../TJ";
import UserData from "../UserData";
import Utils from "../Utils";
import uma from '../uma.min.js';
import MZAd from "../ad/MZAd";
import KSAd from "../ad/KSAd";
import AndroidAd from "../ad/AndroidAd";
import { HS_LOCAL_DATAS } from "../local/hs_local_datas";
import mTimer from "../mTimer";
import GameSys from "./GameSys";
import MiApkAd from "../ad/MiApkAd";

export default class BaseGameSys {

    static bannerH = 140;

    static rewardType: REWARD_TYPE = REWARD_TYPE.VIDEO;

    static scale = 1;

    static screenWidth = 0;

    static screenHeight = 0;

    static isPhoneX = false;

    /** 视频/分享切换*/
    static switchToVideo: boolean;

    static toggleReward:any = 0;
    static toggleTiShi = false;

    /**用户信息 */
    static userInfo = {
        uid: '',
        openid: '',
        avatarUrl: '',
        nickName: ''
    };

    /**按钮延迟展示 */
    static btnDelay = 0;

    /**
     * 广告配置 
     * 【注】SDK已接
     */
    static adInfo = {
        /**Banner广告位 */
        adunit_banner: [],
        /**原生广告位 */
        adunit_native: [],
        /**插屏广告位 */
        adunit_intestital: null,
        /**激励视频广告位 */
        adunit_video: null,
        /**原生广告 */
        adunit_custom: null,
        adunit_appid: null,
        /**九宫格广告位 */
        adunit_portal: null,
        /**互推盒子 */
        adunit_game_banner: null,
        /**是否主动展示九宫格 */
        showGamePortal: true,
        /**banner刷新时间间隔，默认30s */
        bannerUpdateTime: 10,
        /**切换BannerId */
        bannerUpdateNum: 0,
        /**原生广告刷新时间间隔，默认30s */
        customUpdateTime: 30,
        bannerDelay: 0,
        showInterRto: 100,
        showInteNormalRto: 100,
        /**误点原生插屏的概率 */
        forceClickRto: -1,
        nativeInnerInstitialClickWarp: -1,
        /**原生banner误触概率 */
        nativeBannerClickWarp: -1,
        /**两次插屏之间的间隔时间 */
        interTick: 0,
        /**原生插屏"X"号误点概率 */
        closeClickRto: -1,
        /**自动跳转原生广告时间间隔 */
        clickNativeTime: 0,
        /**使用广告池 */
        switchPool: true,
        /**小米插屏、原生展示间隔 */
        miAdGapLimt: 0,
        /**重玩 下一个展示激励视频 */
        QLSP: false,
        /**banner出现n秒后按钮上移 */
        bannerMoveTime: 0,
        /**	宝箱功能是否开启 0关闭 1开启 */
        boxSwitch: 0
    }

    static warpRto = {
        ZJManwc:0,
        YXZanwc:0,
        GQYanwc:0,
        GQYanwc2:0,
        GQYanwc3:0,
        GQYanwc4:0,
        PFSYYanwc:0,
        WZwc:0,
        WZwc2:0,
        WZwc3:0,
        WZwc4:0,
        WZwc5:0,
        WZwc6:0,
        WZwc7:0,
        WZwc8:0
    }

    /**
     * 卖量开关配置 
     * 【注】SDK已接开关
     */
    static recBtnInfo = {
        /**首屏导出，SDK已接 */
        SPDC: false,
        /**卖量功能开关，SDK已接 */
        MLKG: false,
        /**悬浮抖动icon，SDK已接 */
        XFDD: false,
        /**侧边栏，SDK已接 */
        CBL: false,
        /**好友热玩，SDK已接 */
        HYRWGD: false,
        /**热门推荐，SDK已接 */
        RMTJ: false,
        /**爆款游戏，SDK已接 */
        BKYX: false,
        /**今日新游，SDK已接 */
        JRXY: false,
        /**热门推荐排行榜，SDK已接 */
        RMPH: false,
        /**结算页，SDK已接 */
        JSY: false,
        /**更多游戏，SDK已接 */
        GDYX: false,
        /**对联，SDK已接 */
        DL: false,
        /**宝箱开关 */
        BXKG: false
    }

    static isShenHe = false;

    /**场景/地区屏蔽 */
    static isShieldArea = false;
    static isShieldScene = false;

    /**分享文字 */
    static shareWord = [];

    /**分享图片 */
    private static sharePath = 'http://block-wechat.oss-cn-hangzhou.aliyuncs.com/share/qiuqiu.jpg';

    /**屏蔽地区 */
    private static cityList = ['北京','上海','广州','深圳','成都'];
    /**屏蔽场景 */
    private static sceneList = [];
    static lowerPhoneType = 4;
    static recommedList = [];
    private static loopShowAdTimer: mTimer;
    /**展示授权界面 */
    static isShowAuthorize = true;
    /**拒绝是否可以继续游戏 */
    static canPlayWithRefuse = false;

    /**获取网络配置 */
    static initGame(cbk?: () => void) {
        
        // 平台登入
        this.Ad().login();

        if (!Constant.IS_WEB_GAME && !Constant.IS_ANDROID && !Constant.IS_IOS) {
            uma && uma.init({
                appKey: Constant.YM_APPID,
                useOpenid: false, // 因当前暂不支持openid,此处需要设置为false
                debug: true
            });
        }

        let sysInfo = null;
        if (Constant.IS_WECHAT_GAME) {
            wx.showShareMenu({ withShareTicket: true, menus: ['shareAppMessage', 'shareTimeline'] });
            wx.onShareAppMessage(() => {
                return {
                    title: this.shareWord,
                    imageUrl: this.sharePath
                }
            })

            sysInfo = wx.getSystemInfoSync();

        } else if (Constant.IS_BYTEDANCE_GAME) {
            sysInfo = tt.getSystemInfoSync();
        } else if (Constant.IS_BAIDU_GAME) {
            sysInfo = swan.getSystemInfoSync();
        } else if (Constant.IS_BAIDU_GAME) {
            qq.showShareMenu({ withShareTicket: true });
            qq.onShareAppMessage(() => {
                return {
                    title: this.shareWord,
                    imageUrl: this.sharePath
                }
            })
            sysInfo = qq.getSystemInfoSync();
        } else if (Constant.IS_OPPO_GAME) {
            sysInfo = qg.getSystemInfoSync();
        } else if (Constant.IS_VIVO_GAME) {
            sysInfo = qg.getSystemInfoSync();
        } else if (Constant.IS_UC_GAME) {
            sysInfo = uc.getSystemInfoSync();
        } else if (Constant.IS_MEIZU_GAME) {
            sysInfo = qg.getSystemInfoSync();
        } else if (Constant.IS_KS_GAME) {
            sysInfo = ks.getSystemInfoSync();
        }

        if (sysInfo) {
            this.screenWidth = sysInfo.screenWidth;
            this.screenHeight = sysInfo.screenHeight;

            if (window['cc']) {
                if (window['cc'].winSize.width <= window['cc'].winSize.height) {
                    this.scale = this.screenWidth / window['cc'].winSize.width;
                } else {
                    this.scale = this.screenHeight / window['cc'].winSize.height;
                }
            } else if (window['Laya']) {
            }
            this.isPhoneX = sysInfo.model.search('iPhone X') != -1 || sysInfo.model.search('iPhone 11') != -1;
        }

        this.parseData(HS_LOCAL_DATAS);
        
        if (Constant.SDK_TYPE == e_sdk_type.HS) {
            let url = `${Constant.BASE_URL}games/config/${Constant.GID}/${Constant.GAME_VERSION_NAME}`;
            HttpManager.send(url).then(ret => {
                console.log(`[hs_game]remote datas: ${JSON.stringify(ret)}`);
                if (parseInt(ret.result) == 0) {
                    this.parseData(ret)

                    this.Ad().initAd();
                    this.checkIP();
                }
                cbk && cbk();
            }).catch(()=>{
                this.Ad().initAd();
                this.checkIP();
                cbk && cbk();
            })
        }
    }


    private static parseData(ret) {

        if (ret.isShenHe) {
            this.isShenHe = ret.isShenHe == 1;
        }

        if (ret.bannerUpdateTime && Utils.isNumber(ret.bannerUpdateTime)) {
            this.adInfo.bannerUpdateTime = Number(ret.bannerUpdateTime);
        } else if (ret.native_refresh && Utils.isNumber(ret.native_refresh)) {
            this.adInfo.bannerUpdateTime = Number(ret.native_refresh);
        }

        if (ret.bannerUpdateNum) {
            this.adInfo.bannerUpdateNum = ret.bannerUpdateNum;
        }

        if (ret.adunit_banner && StringUtil.trim(ret.adunit_banner) != '') {
            this.adInfo.adunit_banner = StringUtil.toArray(ret.adunit_banner);
        }
        
        if (ret.adunit_native_banner && StringUtil.trim(ret.adunit_native_banner) != '') {
            this.adInfo.adunit_native[ad_native_type.banner] = ret.adunit_native_banner;
        }

        if (ret.adunit_intestital && StringUtil.trim(ret.adunit_intestital) != '') {
            this.adInfo.adunit_intestital = StringUtil.trim(ret.adunit_intestital);
        }

        if (ret.adunit_native_intestital && StringUtil.trim(ret.adunit_native_intestital) != '') {
            this.adInfo.adunit_native[ad_native_type.interstitial] = ret.adunit_native_intestital;
        }

        if (ret.adunit_appid && StringUtil.trim(ret.adunit_appid) != '') {
            this.adInfo.adunit_appid = StringUtil.trim(ret.adunit_appid);
        }

        if (ret.adunit_video && StringUtil.trim(ret.adunit_video) != '') {
            this.adInfo.adunit_video = StringUtil.trim(ret.adunit_video);
        }

        if (ret.adunit_native && StringUtil.trim(ret.adunit_native) != '') {
            this.adInfo.adunit_native[ad_native_type.inner_interstitial] = ret.adunit_native;
        }

        if (ret.adunit_native_icon && StringUtil.trim(ret.adunit_native_icon) != '') {
            this.adInfo.adunit_native[ad_native_type.native_icon] = StringUtil.trim(ret.adunit_native_icon);
        }

        if (ret.share) {
            this.shareWord = StringUtil.toArray(ret.share);
        }

        if (ret.sharePath) {
            this.sharePath = ret.sharePath;
        }

        if (ret.bannerDelay && Utils.isNumber(ret.bannerDelay)) {
            this.adInfo.bannerDelay = Number(ret.bannerDelay);
        }

        if (ret.inte2) {
            this.adInfo.showInterRto = ret.inte2;
        }

        if (ret.inte1) {
            this.adInfo.showInteNormalRto = ret.inte1;
        }

        if (ret.forceclick) {
            this.adInfo.forceClickRto = ret.forceclick;
        }

        if (ret.native_percent) {
            this.adInfo.closeClickRto = ret.native_percent;
        }

        if (ret.intetick) {
            this.adInfo.interTick = ret.intetick;
        }

        if (ret.switch_pool) {
            this.adInfo.switchPool = ret.switch_pool == 1;
        }

        if (ret.of_oppo_sleep) {
            this.btnDelay = ret.of_oppo_sleep;
        }

        if (ret.checkversion == 101) {
            this.rewardType = REWARD_TYPE.SHARE;
        } else if (ret.checkversion == 102) {
            this.rewardType = REWARD_TYPE.VIDEO;
        }
        
        if (ret.recommedPath) {
            let list = StringUtil.toArray(ret.recommedPath);
            for (let appid of list) {
                this.recommedList.push({appId:appid});
            }
        }

        if (ret.cityList) {
            this.cityList = StringUtil.toArray(ret.cityList);
        }

        if (ret.sceneList) {
            this.sceneList = StringUtil.toArray(ret.sceneList);
        }

        if (ret.toggleReward) {
            this.toggleReward = ret.toggleReward == 1;
        }

        if (ret.toggleFuhuo) {
            this.adInfo.nativeInnerInstitialClickWarp = ret.native_inner_institial_click_warp;
        }

        if (ret.toggleTiShi) {
            this.toggleTiShi = ret.toggleTiShi;
        }

        if (ret.native_banner_click_warp) {
            this.adInfo.nativeBannerClickWarp = ret.native_banner_click_warp;
        }

        if (ret.adunit_portal && StringUtil.trim(ret.adunit_portal) != '') {
            this.adInfo.adunit_portal = StringUtil.trim(ret.adunit_portal);
        }

        if (ret.adunit_game_banner && StringUtil.trim(ret.adunit_game_banner) != '') {
            this.adInfo.adunit_game_banner = StringUtil.trim(ret.adunit_game_banner);
        }

        if (ret.show_game_portal) {
            this.adInfo.showGamePortal = ret.show_game_portal == 1;
        }

        if (ret.auto_click_native_time) {
            this.adInfo.clickNativeTime = ret.auto_click_native_time;
        }
        
        if (ret.mi_ad_gap_limit) {
            this.adInfo.miAdGapLimt = ret.mi_ad_gap_limit;
        }

        if (ret.QLSP) {
            this.adInfo.QLSP = ret.QLSP == 1;
        }

        if (ret.baoXiangONOFF) {
            this.adInfo.boxSwitch = ret.baoXiangONOFF;
        }
	
	    this.isShowAuthorize = ret.show_authorize == 1;

        this.canPlayWithRefuse = ret.can_play_refuse == 1;
        //////////////////// 误触 ////////////////////
	    if (ret.ZJManwc) {
	        this.warpRto.ZJManwc = ret.ZJManwc;
	    }

	    if (ret.YXZanwc) {
	        this.warpRto.YXZanwc = ret.YXZanwc;
	    }

	    if (ret.GQYanwc) {
	        this.warpRto.GQYanwc = ret.GQYanwc;
	    }

	    if (ret.GQYanwc2) {
	        this.warpRto.GQYanwc2 = ret.GQYanwc2;
	    }

	    if (ret.GQYanwc3) {
	        this.warpRto.GQYanwc3 = ret.GQYanwc3;
	    }

	    if (ret.GQYanwc4) {
	        this.warpRto.GQYanwc4 = ret.GQYanwc4;
	    }

	    if (ret.PFSYYanwc) {
	        this.warpRto.PFSYYanwc = ret.PFSYYanwc;
	    }
        
	    if (ret.WZwc) {
	        this.warpRto.WZwc = ret.WZwc;
	    }
        
	    if (ret.WZwc2) {
	        this.warpRto.WZwc2 = ret.WZwc2;
	    }
        
	    if (ret.WZwc3) {
	        this.warpRto.WZwc3 = ret.WZwc3;
	    }

	    if (ret.WZwc4) {
	        this.warpRto.WZwc4 = ret.WZwc4;
	    }

	    if (ret.WZwc5) {
	        this.warpRto.WZwc5 = ret.WZwc5;
	    }

	    if (ret.WZwc6) {
	        this.warpRto.WZwc6 = ret.WZwc6;
	    }

	    if (ret.WZwc7) {
	        this.warpRto.WZwc7 = ret.WZwc7;
	    }

	    if (ret.WZwc8) {
	        this.warpRto.WZwc8 = ret.WZwc8;
	    }
        console.log(`[hs_game] ${JSON.stringify(this.adInfo)}`);
        console.log(`[hs_game] ${JSON.stringify(this.warpRto)}`);
    }

    /**
     * 获取广告实例
     */
    static Ad(): AdManager {
        if (Constant.IS_WECHAT_GAME) {
            
        } else if (Constant.IS_OPPO_GAME) {
            if (Constant.SDK_TYPE == e_sdk_type.QL) {
                // return SyyxSdk.getInstance();
            } else if (Constant.SDK_TYPE == e_sdk_type.YDHW) {
            } else {
                return OppoAd.getInstance();
            }
        } else if (Constant.IS_VIVO_GAME) {
            if (Constant.SDK_TYPE == e_sdk_type.QL) {
            } else if (Constant.SDK_TYPE == e_sdk_type.YDHW) {
            } else {
                return VIVOAd.getInstance();
            }
        } else if (Constant.IS_MEIZU_GAME) {
            return MZAd.getInstance();
        } else if (Constant.IS_KS_GAME) {
            return KSAd.getInstance();
        } else if (Constant.IS_ANDROID) {
            let platform = Utils.callMethod('getNativePlatfom');
            if (platform == PLATFORM.MI) {
                return MiApkAd.getInstance();
            }
            return AndroidAd.getInstance();
        } else {
            return AdManager.getInstance();
        }
    }

    /**
     * 微信分享
     * @param complete 完成回调，参数表示是否成功
     */
    static shareGame(complete?: (res: boolean) => void) {
        if (Constant.IS_WECHAT_GAME) {
            wx.shareAppMessage(
                {
                    title: this.shareWord[0],
                    imageUrl: this.sharePath
                });
            let share_time = (new Date()).getTime();

            let func = res => {
                if ((new Date()).getTime() - share_time >= 3000) {
                    complete && complete(true);
                    // wx.showToast({title: '分享成功',duration: 2000});
                } else {
                    wx.showModal({
                        title: "提示",
                        content: "该群已分享过,请换个群",
                        showCancel: true,
                        cancelText: "取消",
                        cancelColor: "#000",
                        confirmText: "去分享",
                        confirmColor: "#08f",
                        success: res => {
                            if (res.confirm) {
                                this.shareGame(complete);
                            } else if (res.cancel) {
                                complete && complete(false);
                            }
                        }
                    });
                }
                wx.offShow(func);
            }
            wx.onShow(func);
        } else if (Constant.IS_QQ_GAME) {
            qq.shareAppMessage({
                title: this.shareWord[0],
                imageUrl: this.sharePath,
                query: '',
                success: () => {
                    complete && complete(true);
                },
                fail: () => {
                    complete && complete(false);
                }
            });
        } else if (Constant.IS_UC_GAME) {
            uc.shareAppMessage();
        }
    }


    /**
     * 打点自定义事件
     * @param eventName 
     * @param params 
     */
    static sendEvent(eventName, params = null) {
        if (Constant.IS_WECHAT_GAME) {
            // 友盟 事件名为后台事件ID
            wx.uma && wx.uma.trackEvent(eventName, params);
        } else if (Constant.IS_ANDROID || Constant.IS_IOS) {
            Utils.callMethod('onEvent', eventName?eventName.toString():'');
        }

        if (Constant.APPID != null && Constant.APPID.replace(' ', '') != '') {
            TJ.DevKit.ReYun.Event(null, eventName);
        }
    }

    /**
     * 关卡开始事件
     * @param stageId 关卡ID
     */
    static levelStart(stageId) {
        if (Constant.IS_WECHAT_GAME) {

        } else if (Constant.IS_OPPO_GAME || Constant.IS_VIVO_GAME) {
            uma && uma.stage.onStart({
                stageId: String(stageId),
                stageName: `第${stageId}关`
            });
        } else if (Constant.IS_ANDROID || Constant.IS_IOS) {
            Utils.callMethod('levelStart', stageId?stageId.toString():'');
        }
        if (Constant.APPID != null && Constant.APPID.replace(' ', '') != '') {
            TJ.DevKit.ReYun.Event(null, `第${stageId}关开始`);
        }
    }

    /**
     * 关卡结束事件
     * @param stageId 关卡ID
     * @param complete 是否完成
     */
    static levelEnd(stageId, complete = false) {
        if (Constant.IS_WECHAT_GAME) {

        } else if (Constant.IS_OPPO_GAME || Constant.IS_VIVO_GAME) {
            uma && uma.stage.onEnd({
                stageId: String(stageId),
                stageName: `第${stageId}关`,
                event: complete ? 'complete' : 'fail'
            })
        } else if (Constant.IS_ANDROID || Constant.IS_IOS) {
            Utils.callMethod('levelEnd', stageId?stageId.toString():'');
        }
        if (Constant.APPID != null && Constant.APPID.replace(' ', '') != '') {
            TJ.DevKit.ReYun.Event(null, `第${stageId}关结束-${complete ? '完成' : '失败'}`);
        }
    }

    /**
     * 系统震动
     * @param isLong 是否长震动
     */
    static vibrate(isLong = false) {
        if (!UserData.vibrate) return;
        if (Constant.IS_WECHAT_GAME) {
            if (wx.vibrateShort && !isLong) {
                wx.vibrateShort();
            } else {
                wx.vibrateLong();
            }
        } else if (Constant.IS_OPPO_GAME || Constant.IS_VIVO_GAME) {
            if (qg.vibrateShort && !isLong) {
                qg.vibrateShort({});
            } else {
                qg.vibrateLong({});
            }
        } else if (Constant.IS_QQ_GAME) {
            if (qq.vibrateShort && !isLong) {
                qq.vibrateShort({});
            } else {
                qq.vibrateLong({});
            }
        } else if (Constant.IS_BYTEDANCE_GAME) {
            if (tt.vibrateShort && !isLong) {
                tt.vibrateShort({});
            } else {
                tt.vibrateLong({});
            }
        } else if (Constant.IS_BAIDU_GAME) {
            if (swan.vibrateShort && !isLong) {
                swan.vibrateShort({});
            } else {
                swan.vibrateLong({});
            }
        } else if (Constant.IS_ANDROID || Constant.IS_IOS) {
            Utils.callMethod('vibrate', !isLong);
        }
    }

    /**
     * 场景/地区屏蔽
     */
    private static checkIP() {
        const IP_URL = "https://gamesdata.hongshunet.com:8443/games/config/ipAddress";
        HttpManager.send(IP_URL).then(ret => {
            if (parseInt(ret.status) === 0) {
                if (!ret.data || !ret.data.city || this.cityList.indexOf(ret.data.region) == -1 && this.cityList.indexOf(ret.data.city) == -1) {
                } else {
                    this.isShieldArea = true;
                }
            }
        });
    }

    private static loadLowerPhone() {
    }

    /**
     * 间隔n秒自动弹/点击广告
     * CLICK: 自动点击 
     * INTER: 自动弹插屏
     * VIDEO: 自动弹激励视频
     * @param type 
     * @param on_show 
     * @param on_hide 处理插屏回调
     */
    static loopShowAd(type = AUTO_AD_TYPE.NO, on_show?:()=>void, on_hide?:()=>void) {
        if (this.adInfo.clickNativeTime > 0 && !this.isShenHe && !this.isShieldArea) {
            if (!this.loopShowAdTimer) {
                this.loopShowAdTimer = new mTimer();
            }
            this.loopShowAdTimer.clear();
            this.loopShowAdTimer.once(()=>{
                this.showAd(type, on_show, on_hide)
            }, this.adInfo.clickNativeTime * 1000)
        }
    }
    
    static loopShowAdClear() {
        this.loopShowAdTimer && this.loopShowAdTimer.clear();
    }

    private static showAd(type, on_show?:()=>void, on_hide?:()=>void) {
        if (type == AUTO_AD_TYPE.CLICK) {
            this.Ad().clickNative();
            this.loopShowAd(type);
        } else if (type == AUTO_AD_TYPE.INTER) {
            this.Ad().showNativeInterstitial(()=>{
                on_show && on_show()
            }, ()=>{
                on_hide && on_hide();
                this.loopShowAd(type, on_show, on_hide);
            })
        } else if (type == AUTO_AD_TYPE.VIDEO) {
            this.Ad().showVideo(()=>{
                this.loopShowAd(type);
            })
        }
    }
}