import { EVENT_TYPE } from "../enum/Enum";
import Utils from "../Utils";

export default class BaseUserData {

    /**金币 */
    static set coin(coin: number) {
        Utils.setItem('COIN', coin);
        Utils.emit(EVENT_TYPE.CHANGE_COIN);
    }

    static get coin() {
        return Utils.getItem('COIN', 0);
    }

    /**体力 */
    static set power(power: number) {
        Utils.setItem('POWER', power);
        Utils.emit(EVENT_TYPE.CHANGE_POWER);
    }

    static get power() {
        return Utils.getItem('POWER', 10);
    }

    static set powerTime(time: number) {
        Utils.setItem('POWERTIME', time);
    }

    static get powerTime() {
        return Utils.getItem('POWERTIME', 0);
    }

    /**已完成最大关卡 */
    static set maxLevel(lv: number) {
        Utils.setItem('MAXLEVEL', lv);
    }

    static get maxLevel(): number {
        return Utils.getItem('MAXLEVEL', 0);
    }

    /**签到时间 */
    static set signDay(day: number) {
        Utils.setItem('SIGNDAY', day);
    }

    static get signDay() {
        return Utils.getItem('SIGNDAY', 0);
    }

    /**签到次数 */
    static set signNum(num: number) {
        Utils.setItem('SIGNNUM', num);
    }

    static get signNum() {
        return Utils.getItem('SIGNNUM', 0);
    }

    /**皮肤信息 */
    static set skinInfo(info) {
        Utils.setItem('SKININFO', info);
    }

    static get skinInfo() {
        return Utils.getItem('SKININFO', {});
    }

    /**当前使用皮肤 */
    static set curSkinUsed(type) {
        Utils.setItem('CURSKINUSED', type);
    }

    static get curSkinUsed() {
        return Utils.getItem('CURSKINUSED', null);
    }

    /**背景音乐是否可播放 */
    static set musicPlay(type) {
        Utils.setItem('MUSIC', type);
    }

    static get musicPlay() {
        return Utils.getItem('MUSIC', true);
    }

    /**音效是否可播放 */
    static set soundPlay(type) {
        Utils.setItem('SOUND', type);
    }

    static get soundPlay() {
        return Utils.getItem('SOUND', true);
    }

    /**是否可震动 */
    static set vibrate(type) {
        Utils.setItem('VIBRATE', type);
    }

    static get vibrate() {
        return Utils.getItem('VIBRATE', true);
    }

    /**是否新玩家 */
    static set isNewPlay(newPlay: boolean) {
        Utils.setItem('NEWPLAY', newPlay);
    }

    static get isNewPlay() {
        return Utils.getItem('NEWPLAY', true);
    }

    /**
     * 随机生成用户UUID
     */
    static get uid() {
        let uid = Utils.getItem('UUID', null);
        if (uid == null) {
            let d = new Date().getTime();
            let uid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                let r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });

            Utils.setItem('UUID', uid);
        }
        return uid;
    }
}