import GameSys from "../game_sys/GameSys";
import mTimer from "../mTimer";
import Utils from "../Utils";
import AdManager from "./AdManager";
import { ad_native_type } from "./hs_enum";

export default class OppoAd extends AdManager {
    
    gameBannerAd: any;
    private _game_portal_hide: () => void;

    static getInstance(): OppoAd {
        if (this.instance == null) {
            this.instance = new OppoAd();
        }
        return this.instance;
    }

    initAd() {
        if (this.isInitAd) return;
        this.isInitAd = true;

        if (GameSys.isShenHe) {
            GameSys.adInfo.bannerDelay = 60;
        }
        
        this.isGameCd = GameSys.adInfo.bannerDelay > 0;

        super.initAd();

        this._gameCd();
        this.initBanner();
        this.initNormalBanner();
        this.initVideo();
        this.initNativeAd();

        this.initGamePortal();
    }

    private _gameCd() {
        let timer = new mTimer();
        timer.once(()=>{
            this.isGameCd = false;
            if (this.isNeedShowBanner) {
                this.showBanner();
            }
        }, GameSys.adInfo.bannerDelay * 1000);
    }

    /**
     * 初始化普通banner
     */
    initNormalBanner() {
        if (this.platformVersion() < 1051 || GameSys.adInfo.adunit_banner.length <= 0) return;

        this.destroyNormalBanner();

        this.bannerAd = qg.createBannerAd({
            adUnitId: GameSys.adInfo.adunit_banner[0],
            style: {}
        })

        this.bannerAd.onError(err=>{
            console.error('[hs_game]normal banner error: ', JSON.stringify(err));
        });
    }

    /**
     * 展示普通banner
     */
    showNormalBanner() {
        if (this.bannerAd == null) {
            this.initNormalBanner();
        }
        if (this.bannerAd == null) return;

        this.bannerAd.show().then(()=>{
            console.log("%c[hs_game]normal banner show success", "color: #33ccff");

            if (this.bannerTimer) this.bannerTimer.stop();
        });
    }

    /**
     * 隐藏普通banner
     */
    hideNormalBanner() {
        if (this.bannerAd) {
            this.bannerAd.hide();
        }
    }

    /**
     * 销毁普通banner
     */
    destroyNormalBanner() {
        if (this.bannerAd) {
            this.bannerAd.destroy();
        }
    }

    initBanner() {
        super.initBanner();
    }

    showBanner() {
        if (this.isGameCd) {
            this.isNeedShowBanner = true;
            return console.log("%c[hs_game]showBanner 广告CD中", "color: #33ccff");
        }

        this.hideBanner();
        
        let native_data = this.getLocalNativeData(ad_native_type.banner);
        
        if (GameSys.adInfo.bannerUpdateTime > 0) {
            if (this.bannerTimer == null) this.bannerTimer = new mTimer();
            this.bannerTimer && this.bannerTimer.once(()=>{
                this.showBanner();
            }, GameSys.adInfo.bannerUpdateTime * 1000);
        }

        if (native_data == null || native_data === undefined) {
            this.showNormalBanner();
        } else {
            let node = cc.instantiate(Utils.getRes('hs_ui/ui_banner', cc.Prefab));
            this.bannerNode = node.getComponent('hs_ui_banner');
            this.bannerNode.show(native_data, ()=>{

            }, ()=>{
                this.bannerTimer && this.bannerTimer.clear();
            });
            this.hideNormalBanner();
        }

    }

    hideBanner() {
        super.hideBanner();
        this.isNeedShowBanner = false;

        this.hideNormalBanner();

    }

    initVideo() {
        if (GameSys.adInfo.adunit_video == null) return;
        this.destroyVideo();
        this.videoAd = qg.createRewardedVideoAd({
            posId: GameSys.adInfo.adunit_video
        });

        this.videoAd.onLoad(function () {
            console.log("%c[hs_game]video load succ", "color: #33ccff");
        });

        this.videoAd.onError(function (err) {
            console.log("%c[hs_game]video error: " + JSON.stringify(err), "color: red");
        });

        this.videoAd.onClose(res => {
            if (res && res.isEnded) {
                this.videocallback && this.videocallback(true);
            } else {
                let node = cc.instantiate(Utils.getRes('hs_ui/ui_watch_video', cc.Prefab));
                let ui_watch_video = node.getComponent('hs_ui_watch_video');
                ui_watch_video && ui_watch_video.show(()=>{
                    this.showVideo(this.videocallback);
                });
            }
        });
    }

    showVideo(complete?: (res: boolean) => void) {

        if (this.videoAd == null) {
            this.initVideo();
        }

        if (this.videoAd == null) {
            complete && complete(true);
            return;
        }

        this.videocallback = complete;


        this.videoAd.load().then(res => {
            this.videoAd.show().then(() => {

            }).catch(() => {
                this.createToast('暂无视频，请稍后再试');
            })
        }).catch(() => {
            this.createToast('暂无视频，请稍后再试');
        })

    }

    destroyVideo() {
        if (this.videoAd) {
            this.videoAd.offLoad();
            this.videoAd.offError();
            this.videoAd.offClose();
        }
        this.videoAd = null;
    }

    create_ad(ad_type) {
        return new Promise((resolve, reject) => {
            let posId = GameSys.adInfo.adunit_native[ad_type];
    
            console.log(ad_type, 'posId = ', posId);
    
            if (posId === undefined || posId == null || this.is_limit_native_length(ad_type) || this.platformVersion() < 1051) return; resolve(null);
    
            let nativeAd = qg.createNativeAd({
                posId: posId
            })

            let on_load = (res) => {
                console.log("%c[hs_game]native data load:", "color: #33ccff");
                if (res && res.adList) {
                    let data = res.adList.pop();
                    data.ad = nativeAd;
                    data.type = ad_type;
                    this.add_native_data(data);
                    console.log("%c[hs_game]native data load succ:" + JSON.stringify(data), "color: #33ccff");
                    nativeAd.offLoad(on_load);
                }
            }
            nativeAd.onLoad(on_load);

            let on_error = (err) => {
                console.log("%c[hs_game]native data error: " + JSON.stringify(err), "color: red");
                nativeAd.offError(on_error);
            }
            nativeAd.onError(on_error);

            nativeAd.load();
            
            setTimeout(resolve, 500);
        });
    }

    /**原生广告 */
    initNativeAd() {
        // 拉取间隔1s
        this.create_ad(ad_native_type.banner).then(()=>{
            return this.create_ad(ad_native_type.native_icon);
        }).then(()=>{
            return this.create_ad(ad_native_type.inner_interstitial);
        }).then(()=>{
            return this.create_ad(ad_native_type.interstitial);
        }).then(()=>{
            this.loop_get_native_data();
        })
    }

    showInterstitialNative(parent, on_click?: () => void, on_show?: () => void, on_hide?: () => void) {
        if (this.isGameCd) {
            on_hide && on_hide();
            return console.log("%c[hs_game]广告CD中", "color: #33ccff");
        }
        this.hideInterstitialNative();

        let native_data = this.getLocalNativeData(ad_native_type.inner_interstitial);

        if (native_data == null || native_data === undefined) {
            on_hide && on_hide();
        } else {

            this.isNeedShowBanner = false;
            
            let node = cc.instantiate(Utils.getRes('hs_ui/ui_inner_interstitial', cc.Prefab));
            this.innerInter = node.getComponent('hs_ui_inner_interstitial');
            this.innerInter && this.innerInter.show(parent, native_data, on_click, () => {
                this.hideBanner();
                on_show && on_show();
            }, on_hide);
        }
    }

    /**隐藏原生横幅 */
    hideInterstitialNative() {
        super.hideInterstitialNative();
    }

    /**
     * 原生ICON
     * @param parent 
     */
    showNativeIcon(parent) {
        if (this.isGameCd) {
            return console.log("%c[hs_game]showNativeIcon 广告CD中", "color: #33ccff");
        }


        // 特殊处理
        let type = ad_native_type.native_icon;
        let posId = GameSys.adInfo.adunit_native[type];
        if (posId == GameSys.adInfo.adunit_native[ad_native_type.inner_interstitial]) {
            type = ad_native_type.inner_interstitial;
        } else if (posId == GameSys.adInfo.adunit_native[ad_native_type.banner]) {
            type = ad_native_type.banner;
        }
        let native_data = this.getLocalNativeData(type);

        if (native_data == null || native_data === undefined) {
            return console.log("%c[hs_game]showNativeIcon 暂无广告数据", "color: #33ccff");
        } else {
            let node = cc.instantiate(Utils.getRes('hs_ui/ui_unit_icon', cc.Prefab));
            this.nativeIcon = node.getComponent('hs_ui_native_icon');
            this.nativeIcon && this.nativeIcon.show(parent, native_data);
        }
    }

    /**隐藏原生ICON */
    hideNativeIcon() {
        super.hideNativeIcon();
    }

    /**
     * 每隔n秒加载一条数据，保持数组内各类型数据有5条
     */
    private loop_get_native_data() {
        let nextTimeLeft = this._native_data_cache.length < 5 ? Utils.randomInt(15, 20) * 1000 : 30000;
        setTimeout(this.initNativeAd.bind(this), nextTimeLeft);
    }

    /**
     * 盒子9宫格
     */
    initGamePortal() {
        if (this.supportGameBox() && GameSys.adInfo.adunit_portal) {
            this.destroyGamePortal()

            this.portalAd = qg.createGamePortalAd({
                adUnitId: GameSys.adInfo.adunit_portal
            });

            this.portalAd.onLoad(function () {
                console.log("%c[hs_game]game portal ad load succ", "color: #33ccff");
            })

            this.portalAd.onClose(() => {
                this.showBanner();
                this._game_portal_hide && this._game_portal_hide();
            })

            this.portalAd.onError(function (err) {
                console.log("%c[hs_game]game portal ad error: " + JSON.stringify(err), "color: red");
            })

        }
    }

    showGamePortal(on_show?: () => void, on_hide?: () => void, show_toast = true) {
        if (!this.supportGameBox()) return on_hide && on_hide();

        if (!this.portalAd) {
            this.initGamePortal();
        }
        if (!this.portalAd) {
            on_hide && on_hide();
            show_toast && this.createToast('努力加载中,请稍后再试~');
            return
        }
        this._game_portal_hide = on_hide;
        this.portalAd.load().then(() => {
            this.portalAd.show().then(() => {
                console.log('show success')
                this.hideBanner();
                on_show && on_show();
            }).catch(error => {
                console.error('showGamePortal show error:', error)
                on_hide && on_hide();
                show_toast && this.createToast('努力加载中,请稍后再试~');
            })
        }).catch(error => {
            console.error('showGamePortal load error:', error)
            on_hide && on_hide();
            show_toast && this.createToast('努力加载中,请稍后再试~');
        });
    }

    destroyGamePortal() {
        if (!this.portalAd) return;

        this.portalAd.destroy();
        this.portalAd = null;
    }

    /**
    * 盒子横幅
    */
    initGameBanner() {
        if (qg.getSystemInfoSync()['platformVersion'] >= 1076 && GameSys.adInfo.adunit_game_banner) {
            this.destroyGameBanner();

            this.gameBannerAd = qg.createGameBannerAd({
                adUnitId: GameSys.adInfo.adunit_game_banner
            });

            this.gameBannerAd.onLoad(function () {
                console.log('盒子横幅广告加载成功')
            })

            this.gameBannerAd.onError(function (err) {
                console.log(err)
            })

        } else {
        }
    }

    showGameBanner() {
        if (!this.gameBannerAd) {
            this.initGameBanner();
        }
        if (!this.gameBannerAd) return;

        this.gameBannerAd.show().then(function () {
            console.log('show success')
        }).catch(function (error) {
            console.log('show fail with:' + error.errCode + ',' + error.errMsg)
        })
    }

    hideGameBanner() {
        if (!this.gameBannerAd) return;

        this.gameBannerAd.hide();
    }

    destroyGameBanner() {
        if (!this.gameBannerAd) return;

        this.gameBannerAd.destroy();
        this.gameBannerAd = null;
    }

    /**
     * 展示添加桌面界面
     * @param on_succ 
     */
    showAddDesktop(on_close?: () => void, on_succ?: () => void) {
        if (this.addIconNode && this.addIconNode !== undefined && cc.isValid(this.addIconNode.node)) return;

        let node = cc.instantiate(Utils.getRes('hs_ui/ui_add_icon', cc.Prefab));
        this.addIconNode = node.getComponent('hs_ui_add_icon');
        this.addIconNode && this.addIconNode.show(on_succ);
    }

    /**判断是否支持添加桌面 */
    hasAddDesktop(can_add?: () => void, has_add?: () => void, on_fail?: () => void) {
        if (this.platformVersion() >= 1044) {
            qg.hasShortcutInstalled({
                success: res => {
                    // 判断图标未存在时，创建图标
                    console.log("%c[hs_game] hasShortcutInstalled " + (res? 'has add':'can add'), "color: #33ccff");
                    if (res == false) {
                        can_add && can_add();
                    } else {
                        has_add && has_add();
                    }
                },
                fail: err => {
                    console.error(`[hs_game] hasShortcutInstalled error: ${JSON.stringify(err)}`);
                    on_fail && on_fail();
                },
                complete: function () { }
            })
        } else {
            on_fail && on_fail();
        }
    }

    /**创建桌面图标 */
    addDesktop(on_succ?: () => void, on_fail?: () => void) {
        if (this.platformVersion() >= 1040) {
            qg.installShortcut({
                success: () => {
                    setTimeout(() => {
                        this.hasAddDesktop(() => {
                            on_fail && on_fail();
                        }, () => {
                            on_succ && on_succ();
                        })
                    }, 1000);
                },
                fail: err => {
                    console.error(`[hs_game] installShortcut error: ${JSON.stringify(err)}`);
                    on_fail && on_fail();
                }
            })
        } else {
            on_fail && on_fail();
        }
    }

    login(on_succ?: (res) => void, on_fail?: (err) => void) {
        if (this.platformVersion() >= 1040) {
            qg.login({
                success: res=>{
                    on_succ && on_succ(res);
                },
                fail: (err)=>{
                    on_fail && on_fail(err);
                }
            })
        }
    }
}
