
import AdManager from "./AdManager";

export default class UCAd extends AdManager {
    
}
