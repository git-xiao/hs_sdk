import GameSys from "../tools/game_sys/GameSys";
import UserData from "../tools/UserData";

const {ccclass, property} = cc._decorator;

@ccclass
export default class hs_ui_authorize extends cc.Component {

    private onAgree = null;
    private onRefuse = null;

    show(on_agree?:()=>void, on_refuse?:()=>void) {
        if (this.node.parent) return;
        this.onAgree = on_agree;
        this.onRefuse = on_refuse;

        if (this.is_agree || !GameSys.isShowAuthorize) {
            this.onAgree && this.onAgree();

            this.destroy();
        } else {
            cc.director.getScene().addChild(this.node);
            this.on_show();
        }
    }

    start() {
        this.node.zIndex = cc.macro.MAX_ZINDEX;
    }

    on_show() {
        
    }

    show_privacy(event, type) {
        GameSys.Ad().showPrivacy(type);
    }

    on_agree() {
        this.onAgree && this.onAgree();

        cc.sys.localStorage.setItem(`${UserData.uid}privacy`, this.get_time());

        this.node.destroy();
    }

    on_refuse() {
        if (GameSys.canPlayWithRefuse) {
            this.onAgree && this.onAgree();
        } else {
            this.onRefuse && this.onRefuse();
        }

        this.node.destroy();
    }

    get is_agree() {
        let time = cc.sys.localStorage.getItem(`${UserData.uid}privacy`);
        
        if (time == null || time == 'null' || time === '' || time === undefined) {
            time = 0;
        }
        
        return this.get_time() - time < 120 * 24 * 3600 * 1000;
    }

    get_time() {
        return new Date().getTime();
    }
}