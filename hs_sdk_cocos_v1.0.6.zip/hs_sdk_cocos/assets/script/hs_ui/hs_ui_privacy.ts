import { privacy_type } from "../tools/ad/hs_enum";

const {ccclass, property} = cc._decorator;

@ccclass
export default class hs_ui_authorize extends cc.Component {

    @property(cc.Node)
    bg = null;

    @property(cc.ScrollView)
    textArea:cc.ScrollView = null;

    @property(cc.ToggleContainer)
    toggleContainer:cc.ToggleContainer = null;

    private tabType: privacy_type = null;
    private privacyCon = null;

    show(type = privacy_type.user) {
        if (this.node.parent) return;
        this.tabType = type;

        cc.director.getScene().addChild(this.node);

        this.on_show();
    }

    hide() {
        this.node.destroy();
    }

    start() {
        this.node.zIndex = cc.macro.MAX_ZINDEX;
        
        cc.loader.loadRes('hs_cfg/privacy', cc.JsonAsset, (err, json)=>{
            if (err) {
                console.error('[hs_game] 隐私文件读取失败'+ JSON.stringify(err));
                return;
            }
            this.privacyCon = json.json;
            this.change_tab(this.tabType);
        });
    }
    
    
    on_show(): void {
        this.set_frame_roi();

        this.change_tab(this.tabType);
    }

    set_frame_roi() {
        console.log(this.bg);
        
        if (cc.winSize.width <= cc.winSize.height) {
            this.bg.width = 521;
            this.bg.height = 717;
        } else {
            this.bg.width = 717;
            this.bg.height = 521;
        }
    }

    on_change_tab(event, type) {
        this.change_tab(type);
    }

    change_tab(type?) {
        this.tabType = type;

        for (let item of this.toggleContainer.toggleItems) {
            if (item.name.indexOf(type) >= 0) {
                item.check();
            }
        }

        if (this.privacyCon) {
            
            let label = this.textArea.content.getComponent(cc.Label);
            if (this.privacyCon.hasOwnProperty(this.tabType)) {
                label.string = this.privacyCon[this.tabType];
            } else {
                label.string = '';
            }
            this.textArea.scrollTo(cc.v2(0, 1), 0);
        }
    }

    onDisable(): void {
    }
}