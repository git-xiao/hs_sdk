import { EVENT_TYPE } from "../tools/enum/Enum";
import GameSys from "../tools/game_sys/GameSys";
import Utils from "../tools/Utils";
import { ui } from "../ui/layaMaxUI";

export default class hs_ui_watch_video extends ui.hs_ad.hs_ui_watch_videoUI {
    videoComplete: () => void;
    onSucc: () => void;
    
    constructor() { 
        super();
     }

    onAwake() {
        this.size(Laya.stage.width, Laya.stage.height);
        
        this.zOrder = 10000;
    }

    show(on_succ?:()=>void) {
        if (this.parent == null) {
            Laya.stage.addChild(this);

            this.onSucc = on_succ;
        }
    }
    
    onEnable(): void {
        this.btnWatchAd.visible = false;
        this.btnClose.clickHandler = Laya.Handler.create(this, this.tapClose, null, false);
        this.btnWatchAd.clickHandler = Laya.Handler.create(this, this.tapWatchAd, null, false);
        this.btnWatchVideo.clickHandler = Laya.Handler.create(this, this.tapWatchVideo);

        this.showInterstitialNative();
    }

    tapWatchVideo() {
        this.onSucc && this.onSucc();
        this.destroy();
    }

    tapClose() {
        this.destroy();
    }

    tapWatchAd() {
        GameSys.Ad().clickNativeInnerInterstitial();
    }

    onDisable(): void {
    }
    
    showInterstitialNative() {
        this.btnWatchAd.visible = false;
        this.btnWatchAd.clickHandler = Laya.Handler.create(this, ()=>{
            GameSys.Ad().clickNativeInnerInterstitial();
        });
        GameSys.Ad().showInterstitialNative(this.nativeInner, ()=>{

        }, ()=>{
            this.btnWatchAd.visible = true;
        }, ()=>{
            this.btnWatchAd.visible = false;
            GameSys.Ad().showBanner();
        });
    }
}