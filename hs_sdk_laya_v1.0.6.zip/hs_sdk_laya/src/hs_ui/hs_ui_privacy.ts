import { privacy_type } from "../tools/ad/hs_enum";
import { ui } from "../ui/layaMaxUI";

export default class hs_ui_privacy extends ui.hs_ad.hs_ui_privacyUI {
    private tabType: privacy_type = null;
    private privacyCon = null;
    
    constructor() { super(); }

    show(type = privacy_type.user) {
        this.tabType = type;

        if (this.parent) return;
        Laya.stage.addChild(this);

        this.on_show();
    }

    hide() {
        this.destroy();
    }

    onAwake() {
        this.zOrder = 10000;
        
        Laya.loader.load('hs_cfg/privacy.json', Laya.Handler.create(this, json=>{
            this.privacyCon = json;
            this.change_tab(this.tabType);
        }), null, Laya.Loader.JSON);

        this.user.clickHandler = Laya.Handler.create(this, this.change_tab, [privacy_type.user], false);
        this.privacy.clickHandler = Laya.Handler.create(this, this.change_tab, [privacy_type.privacy], false);
        this.btnClose.clickHandler = Laya.Handler.create(this, this.hide, null, false);
        this.panel.on(Laya.Event.CLICK, this, this.hide);
    }
    
    
    on_show(): void {
        this.set_frame_roi();
        
        this.loading.visible = true;

        this.change_tab(this.tabType);
    }

    set_frame_roi() {
        if (Laya.stage.width <= Laya.stage.height) {
            this.bg.size(521, 717);
        } else {
            this.bg.size(717, 521);
        }
    }

    change_tab(type?) {
        this.tabType = type;

        let tab = this[type].parent as Laya.HBox;
        
        for (let i = 0; i < tab.numChildren; i++) {
            let child = tab.getChildAt(i);
            if (child == this[type]) {
                (<Laya.Button>child).mouseEnabled = false;
                (<Laya.Sprite>child.getChildByName('normal')).visible = false;
                (<Laya.Sprite>child.getChildByName('selected')).visible = true;
            } else {
                (<Laya.Button>child).mouseEnabled = true;
                (<Laya.Sprite>child.getChildByName('normal')).visible = true;
                (<Laya.Sprite>child.getChildByName('selected')).visible = false;
            }
        }

        if (this.privacyCon) {
            if (this.privacyCon.hasOwnProperty(this.tabType)) {
                this.textArea.text = this.privacyCon[this.tabType];
            } else {
                this.textArea.text = '';
            }
            this.loading.visible = false;
        }
        this.textArea.scrollTo(0);
        this.textArea.vScrollBarSkin = '';
    }

    onDisable(): void {
    }
}