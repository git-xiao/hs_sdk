import { EVENT_TYPE } from "../tools/enum/Enum";
import GameSys from "../tools/game_sys/GameSys";
import Utils from "../tools/Utils";
import { ui } from "../ui/layaMaxUI";

export default class hs_ui_share_rcorder extends ui.hs_ad.ui_share_recorderUI {
    onSucc: () => void;
    onFail: () => void;
    
    constructor() { super(); }

    show(on_succ?:()=>void, on_fail?:()=>void) {
        if (this.parent == null) {
            Laya.stage.addChild(this);

            this.onSucc = on_succ;
            this.onFail = on_fail;
        }
    }
    
    onEnable(): void {
        GameSys.Ad().showBanner();

        this.btnClose.clickHandler = Laya.Handler.create(this, ()=>{
            this.destroy();
        })

        this.btnShare.clickHandler = Laya.Handler.create(this, ()=>{
            GameSys.Ad().shareRecorder(()=>{
                this.onSucc && this.onSucc();
                this.destroy();
            }, this.onFail);
        }, null, false)
    }

    onDisable(): void {
        
    }
}