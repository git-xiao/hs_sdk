import GameSys from "../tools/game_sys/GameSys";
import { ui } from "../ui/layaMaxUI";

export default class hs_ui_add_icon extends ui.hs_ad.hs_ui_add_iconUI {
    on_succ: () => void;
    on_close: () => void;

    constructor() {
        super();
    }

    onAwake() {
        this.size(Laya.stage.width, Laya.stage.height);

        this.zOrder = 10000;
    }

    onEnable(): void {
        this.btnWatchAd.visible = false;
        this.btnAddIcon.clickHandler = Laya.Handler.create(this, this.tapAddIcon, null, false);
        this.btnClose.clickHandler = Laya.Handler.create(this, this.tapClose, null, false);
        this.btnWatchAd.clickHandler = Laya.Handler.create(this, this.tapWatchAd, null, false);

        this.showInterstitialNative();
    }

    show(on_close?:()=>void, on_succ?:()=>void) {
        if (this.parent == null) {
            Laya.stage.addChild(this);
            this.on_succ = on_succ;
            this.on_close = on_close;
        }
    }

    tapAddIcon() {
        GameSys.Ad().addDesktop(() => {
            this.btnAddIcon.visible = false;

            this.on_succ && this.on_succ();
        }, null);
    }

    tapClose() {
        this.destroy();
        this.on_close && this.on_close();
    }

    tapWatchAd() {
        GameSys.Ad().clickNativeInnerInterstitial();
    }

    onDisable(): void {
    }
    showInterstitialNative() {
        this.btnWatchAd.visible = false;
        this.btnWatchAd.clickHandler = Laya.Handler.create(this, ()=>{
            GameSys.Ad().clickNativeInnerInterstitial();
        });
        GameSys.Ad().showInterstitialNative(this.nativeInner, ()=>{

        }, ()=>{
            this.btnWatchAd.visible = true;
        }, ()=>{
            this.btnWatchAd.visible = false;
            GameSys.Ad().showBanner();
        });
    }
}