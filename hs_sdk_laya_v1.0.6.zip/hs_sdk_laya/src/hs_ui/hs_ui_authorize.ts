import { privacy_type } from "../tools/ad/hs_enum";
import GameSys from "../tools/game_sys/GameSys";
import UserData from "../tools/UserData";
import Utils from "../tools/Utils";
import { ui } from "../ui/layaMaxUI";

export default class hs_ui_authorize extends ui.hs_ad.hs_ui_authorizeUI {

    private onAgree = null;
    private onRefuse = null;
    
    constructor() { super(); }

    show(on_agree?:()=>void, on_refuse?:()=>void) {
        if (this.parent) return;
        this.onAgree = on_agree;
        this.onRefuse = on_refuse;

        if (this.is_agree) {
            this.onAgree && this.onAgree();

            this.destroy();
        } else {
            Laya.stage.addChild(this);
            this.on_show();
        }
    }

    onAwake() {
        this.zOrder = 9999;
        this.user.on(Laya.Event.CLICK, this, this.show_privacy_content, [privacy_type.user]);
        this.privacy.on(Laya.Event.CLICK, this, this.show_privacy_content, [privacy_type.privacy]);
        this.btnSure.on(Laya.Event.CLICK, this, this.on_agree);
        this.btnCancel.on(Laya.Event.CLICK, this, this.on_refuse);
    }

    on_show() {
        
    }

    show_privacy_content(type) {
        GameSys.Ad().showPrivacy(type);
    }

    on_agree() {
        this.onAgree && this.onAgree();

        
        Utils.setItem(`${UserData.uid}privacy`, this.get_time());

        this.destroy();
    }

    on_refuse() {
        this.onRefuse && this.onRefuse();

        this.destroy();
    }

    get is_agree() {
        let time = Utils.getItem(`${UserData.uid}privacy`, 0);
        
        return this.get_time() - time < 120 * 24 * 3600 * 1000;
    }

    get_time() {
        return new Date().getTime();
    }
}