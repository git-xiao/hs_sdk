import { ad_native_type } from "../../tools/ad/hs_enum";
import GameSys from "../../tools/game_sys/GameSys";
import { ui } from "../../ui/layaMaxUI";


export class hs_ui_native_icon extends ui.hs_ad.ui_native_iconUI {
    /**
   * 原生广告数据
   */
    native_data

    constructor() {
        super();
        this.game_icon.on(Laya.Event.CLICK, this, this.on_click_adv)
        this.btn_close.on(Laya.Event.CLICK, this, this.on_click_close)
    }

    on_click_adv(evt: Laya.Event) {
        this.report_click();
    }

    on_click_close() {
        this.hide();
    }

    /**
    * 广告被点击
    */
    report_click() {
        if (this.native_data) {
            GameSys.Ad().reportAdClick(this.native_data)
            // 自动切换
            this.update_view();
        }
    }

    /**
    * 广告被曝光
    */
    report_show() {
        if (this.native_data) {
            GameSys.Ad().reportAdShow(this.native_data)
        }
    }

    show(parent, native_data) {
        if (!this.parent) {
            this.native_data = native_data
            !this.parent && parent.addChild(this);
            this.on_show();
        }
    }

    onEnable() {
        this.auto_update_ad();
    }

    protected auto_update_ad() {
        if (GameSys.adInfo.bannerUpdateTime > 0) {
            this.timer.loop(GameSys.adInfo.bannerUpdateTime * 1000, this, this.update_view);
        }
    }

    protected update_view() {
        if (!this.parent || !this.visible) return;
        let native_data = GameSys.Ad().getLocalNativeData(ad_native_type.native_icon);
        if (native_data) {
            this.native_data = native_data;
            this.refresh();
        }
    }

    /**
     * 上报点击后  重新拉取原生数据刷新界面
     */
    report_click_update_view(native_data) {
        if (this.parent) {
            this.native_data = native_data
            this.refresh()
        }
    }

    on_hide() {

    }

    on_show() {
        this.refresh()
    }

    refresh() {
        // this.shake_ani.play(0, false)

        let image_list = this.native_data.imgUrlList;
        if (image_list.length <= 0) {
            image_list = this.native_data.iconUrlList;
        }
        let url = null;
        if (image_list.length > 0) {
            url = image_list[0];
        }
        this.game_icon.skin = url;
        this.report_show()
    }

    /**
    * 移除，并回收
    */
    hide() {
        if (this.parent) {
            this.removeSelf();
            this.on_hide();
        }
    }
}