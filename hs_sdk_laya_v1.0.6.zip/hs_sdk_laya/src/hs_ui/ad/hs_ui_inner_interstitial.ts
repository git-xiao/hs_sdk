import { ad_native_type } from "../../tools/ad/hs_enum";
import GameSys from "../../tools/game_sys/GameSys";
import { ui } from "../../ui/layaMaxUI";

export default class hs_ui_inner_interstitial extends ui.hs_ad.ui_inner_interstitialUI {
    
    native_data

    // 点击结算原生回调
    click_back: Function = undefined
    // 结算原生显示回调
    show_back
    // 结算原生隐藏回调
    hide_back

    constructor() {
        super();
        this.box_close.on(Laya.Event.CLICK, this, this.on_click_close);
        this.icon_video.on(Laya.Event.CLICK, this, this.on_click_adv);

        this.set_background_on_show()
    }

    on_click_adv(evt: Laya.Event) {
        this.report_click()

    }
    
    has_click_warp = false;
    click_adv_warp() {
        this.report_click();
        this.has_click_warp = true;
    }

    on_click_close() {
        this.hide();
    }

    /**
    * 广告被点击
    */
    report_click() {
        if (this.native_data) {
            this.click_back && this.click_back()
            GameSys.Ad().reportAdClick(this.native_data)
            console.log("has clicked native inner interstitial")

            // 自动切换
            this.update_view();
        } else {
            console.log("ui_inner_interstitial report_click native_data is null!")
        }
    }

    /**
    * 广告被曝光
    */
    report_show() {
        if (this.native_data) {
            GameSys.Ad().reportAdShow(this.native_data)
        } else {
        }
    }

    show(parent, native_data, click_back?: Function, show_back?: Function, hide_back?: Function, is_new_type?: boolean) {
        if (!this.parent && parent) {
            this.native_data = native_data
            this.show_back = show_back || undefined
            this.hide_back = hide_back || undefined
            this.click_back = click_back || undefined
            
            parent.addChild(this);
            this.set_default_pos(parent)
            this.on_show();
        }
    }

    onEnable() {
        this.auto_update_ad();
    }

    protected auto_update_ad() {
        if (GameSys.adInfo.bannerUpdateTime > 0) {
            this.timer.loop(GameSys.adInfo.bannerUpdateTime * 1000, this, this.update_view);
        }
    }

    protected update_view() {
        let native_data = GameSys.Ad().getLocalNativeData(ad_native_type.inner_interstitial);
        if (native_data && this.parent && this.activeInHierarchy) {
            this.native_data = native_data;
            this.refresh();
        }
    }

    /**
     * 应用默认的位置
     * 位于父节点中心
     */
    protected set_default_pos(parent?) {
        if (parent) {
            this.x = parent.width / 2 - (this.width * this.scaleX) / 2
            this.y = parent.height / 2 - (this.height * this.scaleY) / 2
        }
    }

    protected set_style_pos(x, y) {

    }

    on_hide() {
        this.timer.clearAll(this);
    }

    on_show() {
        this.refresh()
        // ad_native_inner_interstitial.show_count++
        this.show_back && this.show_back()
    }

    refresh() {
        let image_list = this.native_data.imgUrlList;
        if (image_list.length <= 0) {
            image_list = this.native_data.iconUrlList;
        }
        let url = null;
        if (image_list.length > 0) {
            url = image_list[0];
        }
        this.icon_video.skin = url;

        this.txt_title.text = this.native_data.title;
        this.text_desc.text = this.native_data.desc;
        this.report_show()
    }

    /**
    * 移除，并回收
    */
    hide() {
        if (this.parent) {
            this.removeSelf();
            this.on_hide();
        }
    }

    set_background_on_show() {
        
    }

    onDisable() {
        this.hide_back && this.hide_back()
	    this.hide_back = null
        this.timer.clearAll(this);
    }
    
    onDestroy() {
        this.hide_back && this.hide_back()
	    this.hide_back = null
        this.timer.clearAll(this);
    }
}