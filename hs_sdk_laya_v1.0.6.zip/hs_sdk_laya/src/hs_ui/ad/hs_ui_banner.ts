import { ad_native_state, ad_native_type } from "../../tools/ad/hs_enum"
import GameSys from "../../tools/game_sys/GameSys"
import { ui } from "../../ui/layaMaxUI"


export default class hs_ui_banner extends ui.hs_ad.ui_bannerUI {

    /**
     * 原生广告数据
     */
    native_data

    /**
     * 是否为易点击模式
     */
    easy_click_model = true

    is_set_style = false

    /**
     * 原生banner展示次数
     */
    show_count = 0
    next_change_height_count = -1
    next_change_scale_count = -1

    timer_id = undefined
    is_heighting = false
    onShow = null
    onHide = null

    constructor() {
        super();
        this.icon_close.on(Laya.Event.CLICK, this, this.on_click_close)

        //设置默认位置
        this.set_default_pos()
    }

    has_click_warp = false;
    click_adv_warp() {
        this.report_click();
        this.has_click_warp = true;
    }

    on_click_adv2() {
        this.report_click();
    }

    on_click_adv(evt: Laya.Event) {
        this.report_click();
    }

    on_click_close() {
        this.hide();
    }

    /**
    * 广告被点击
    */
    report_click() {
        if (this.native_data) {
            GameSys.Ad().reportAdClick(this.native_data)

            // 自动切换
            this.update_view();
        }
    }


    /**
     * 广告被曝光
     */
    report_show() {
        if (this.native_data) {
            GameSys.Ad().reportAdShow(this.native_data)
        }
    }

    show(native_data, on_show?, on_hide?) {
        if (!this.parent) {
            Laya.stage.addChild(this);
            this.zOrder = 1000000;
            this.on_show(native_data); 

            this.onShow = on_show;
            this.onHide = on_hide;
        }
    }

    protected update_view() {
        if (!this.parent || !this.visible) return;
        let native_data = GameSys.Ad().getLocalNativeData(ad_native_type.banner);
        if (native_data) {
            this.native_data = native_data;
            this.refresh();
        }
    }

    /**
     * 应用默认的位置
     */
    protected set_default_pos() {
        if (Laya.stage.screenMode == 'vertical' || Laya.stage.height >= Laya.stage.width) {
            this.scaleX = this.scaleY = Laya.stage.width / this.width;
        }
        let size = { width: this.width * this.scaleX, height: this.height * this.scaleY };
        if (!this.is_set_style) {
            let x = (Laya.stage.width - size.width) / 2;
            this.x = x
        }

        let y = Laya.stage.height - size.height;
        this.y = y
    }

    protected resume_pos_and_scale() {
        this.is_set_style = false
        //重新设置一下位置和缩放
        this.scaleX = this.scaleY = Laya.stage.width / this.width;
        this.set_default_pos()
    }

    on_hide() {
        if (this.easy_click_model) {
            this.native_bg.off(Laya.Event.MOUSE_OVER, this, this.on_click_adv2)
        } else {
            this.native_bg.off(Laya.Event.CLICK, this, this.on_click_adv)
        }

        this.timer.clearAll(this);
        this.onHide && this.onHide();
    }

    on_show(native_data?) {
        this.show_count++
        //设置易点击
        if (this.easy_click_model) {
            this.native_bg.on(Laya.Event.MOUSE_OVER, this, this.on_click_adv2)
        } else {
            this.native_bg.on(Laya.Event.CLICK, this, this.on_click_adv)
        }

        if (native_data) {
            this.native_data = native_data
        } else {
            this.native_data = GameSys.Ad().getLocalNativeData(ad_native_type.banner)
        }
        this.refresh()

        this.onShow && this.onShow();
    }

    refresh() {
        let node = this.box_big_banner
        let icon = node.getChildByName("icon") as Laya.Image;
        let title = node.getChildByName("title") as Laya.Text;
        let desc = node.getChildByName("desc") as Laya.Text;
        
        let image_list = this.native_data.imgUrlList;
        if (image_list.length <= 0) {
            image_list = this.native_data.iconUrlList;
        }
        let url = null;
        if (image_list.length > 0) {
            url = image_list[0];
        }
        icon.skin = url;

        title.text = this.native_data.title;
        desc.text = this.native_data.desc;

        this.report_show()
    }

    /**
    * 移除，并回收
    */
    hide() {
        if (this.parent) {
            this.removeSelf();
            this.on_hide();
        }
    }
    
    onDisable() {
        this.timer.clearAll(this);
    }

    onDestroy() {
        this.timer.clearAll(this);
    }
}