
import { ad_native_type } from "../../tools/ad/hs_enum";
import Constant from "../../tools/const/Constant";
import GameSys from "../../tools/game_sys/GameSys";
import { ui } from "../../ui/layaMaxUI";

export default class hs_ui_interstitial extends ui.hs_ad.ui_interstitialUI {
    native_data
    // 结算原生显示回调
    show_back
    // 结算原生隐藏回调
    hide_back
    has_easy_click: boolean;

    constructor() {
        super();
        this.box_close.on(Laya.Event.CLICK, this, this.on_click_close)
        this.btn_click_button.on(Laya.Event.CLICK, this, this.on_click_adv)
        this.icon_video.on(Laya.Event.CLICK, this, this.on_click_adv)
        this.easy_click.on(Laya.Event.CLICK, this, this.on_click_adv2)
        this.ad_bg.on(Laya.Event.CLICK, this, this.on_click_adv)
        
        this.set_background_on_show()

        if (Constant.IS_OPPO_GAME) {
            this.ad_bg.skin = '';
            this.ad_logo.bottom = 342;
            this.txt_title.color = '#ffffff';
            this.text_desc.color = '#ffffff';
        }
    }

    on_click_adv(evt: Laya.Event) {
        this.report_click();
    }

    on_click_adv2(evt: Laya.Event) {
        this.easy_click.visible = false;
        this.has_easy_click = true;

        this.report_click();
    }

    on_click_close() {
        if (!GameSys.isShieldArea && GameSys.adInfo.closeClickRto >= 0 && Math.random() * 100 <= GameSys.adInfo.closeClickRto && !this.has_easy_click) {
            this.easy_click.visible = false;
            this.report_click()
        }
        this.hide();
    }

    /**
    * 广告被点击
    */
    report_click() {
        if (this.native_data) {
            GameSys.Ad().reportAdClick(this.native_data);

            // 自动切换
            let native_data = GameSys.Ad().getLocalNativeData(ad_native_type.interstitial);
            if (native_data && this.parent) {
                this.native_data = native_data
                this.refresh();
            }
        }
    }

    /**
    * 广告被曝光
    */
    report_show() {

        if (this.native_data) {
            GameSys.Ad().reportAdShow(this.native_data);
        }

    }

    show(native_data, on_show, on_hide) {
        if (!this.parent) {
            this.native_data = native_data
            let order = 10000
            Laya.stage.addChild(this);
            this.zOrder = order;

            this.show_back = on_show;
            this.hide_back = on_hide;

            this.on_show();
        }
    }

    /**
     * 应用默认的位置
     */
    protected set_default_pos() {
        // let size = syyx_sdk_utils.get_size(this);
        // let x = (Laya.stage.width - size.width) / 2;
        // let y = (Laya.stage.height - size.height) / 2;
        // this.pos(x, y)
    }

    protected set_style_pos(x, y) {

    }

    on_hide() {
    }

    on_show() {
        this.refresh();

        this.set_easy_click_size();
        
        this.show_back && this.show_back()
    }

    refresh() {
        let image_list = this.native_data.imgUrlList;
        if (image_list.length <= 0) {
            image_list = this.native_data.iconUrlList;
        }
        let url = null;
        if (image_list.length > 0) {
            url = image_list[0];
        }
        this.icon_video.skin = url;
        
        this.txt_title.text = this.native_data.title;
        this.text_desc.text = this.native_data.desc;


        this.report_show()
    }

    /**
    * 移除，并回收
    */
    hide() {
        if (this.parent) {
            this.removeSelf();
            this.on_hide();
        }
    }

    set_background_on_show() {
        
    }

    set_easy_click_size() {
        this.easy_click.visible = false;
        if (!GameSys.isShieldArea && GameSys.adInfo.forceClickRto >= 0 && Math.random() * 100 <= GameSys.adInfo.forceClickRto) {
            if (GameSys.adInfo.forceClickRto <= 30) {
                if (Laya.stage.screenMode == 'horizontal') {
                    this.easy_click.height = Laya.stage.height;
                    this.easy_click.width = 800;
                } else {
                    this.easy_click.width = Laya.stage.width;
                    this.easy_click.height = 800;
                }
            } else if (GameSys.adInfo.forceClickRto <= 60) {
                if (Laya.stage.screenMode == 'horizontal') {
                    this.easy_click.height = Laya.stage.height;
                    this.easy_click.width = 800 + (Laya.stage.width - 800) / 3;
                } else {
                    this.easy_click.width = Laya.stage.width;
                    this.easy_click.height = 800 + (Laya.stage.height - 800) / 3;
                }
            } else {
                this.easy_click.height = Laya.stage.height;
                this.easy_click.width = Laya.stage.width;
            }
            this.easy_click.visible = true;
        }
    }

    onDisable() {
        this.hide_back && this.hide_back()
	this.hide_back = null
    }
    
    onDestroy() {
	this.hide_back = null
    }
}