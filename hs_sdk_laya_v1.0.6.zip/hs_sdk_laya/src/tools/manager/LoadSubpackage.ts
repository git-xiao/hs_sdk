import Constant from "../const/Constant";
import { EVENT_TYPE } from "../enum/Enum";
import Utils from "../Utils";

export default class LoadSubpackage {
    private packageList = [];
    private loadedList = [];
    private loadTotalCount = 0;
    private mustLoadedCount = 0;
    private static ins: LoadSubpackage;
    private on_progress: (progress: any) => void;
    private on_complete: () => void;

    static init(on_progress?:(progress)=>void, on_complete?:()=>void) {
        if (this.ins == null) {
            this.ins = new LoadSubpackage();
        } else {
            return this.ins;
        }

        this.ins.on_progress = on_progress;
        this.ins.on_complete = on_complete;

        if (Constant.subpackage.length <= 0 || Constant.IS_WEB_GAME) {
            this.ins.on_progress && this.ins.on_progress(1);
            this.ins.on_complete && this.ins.on_complete();
        } else {
            this.ins.sortByPriority();
        }

        return this.ins;
    }

    private sortByPriority() {
        for (let data of Constant.subpackage) {
            if (data.priority >= 5) {
            } else {
                ++this.loadTotalCount;
            }
            this.packageList.push(data);
        }

        this.packageList.sort((a, b) => {
            return a.priority - b.priority;
        });

        this.loadSubpackage();
    }

    private loadSubpackage() {
        let data = this.packageList[0];
        let subTask = null;

        let on_succ = ()=>{
            console.log(`[${data.name}]子包加载成功`);
            this.loadedList.push(data.name);
            if (data.priority < 5) {
                if (++this.mustLoadedCount >= this.loadTotalCount) {
                    this.on_complete && this.on_complete();
                }
            }

            this.packageList.splice(0, 1);
            if (this.packageList.length > 0) {
                this.loadSubpackage();
            }
        }

        let on_fail = err => {
            console.error(`[${data.name}]子包加载失败：${JSON.stringify(err)}`);
        }
        if (Constant.IS_OPPO_GAME || Constant.IS_VIVO_GAME) {
            subTask = qg.loadSubpackage({
                name: data.name,
                success: on_succ,
                fail: on_fail
            });
        } else if (Constant.IS_KS_GAME) {
            subTask = ks.loadSubpackage({
                name: data.name,
                success: on_succ,
                fail: on_fail
            });
        } else if (Constant.IS_BAIDU_GAME) {
            subTask = swan.loadSubpackage({
                name: data.name,
                success: on_succ,
                fail: on_fail
            });
        }

        subTask.onProgressUpdate(res => {
            // 加载进度百分比
            if (this.loadTotalCount > 0) {
                let progress = this.mustLoadedCount / this.loadTotalCount + res["progress"];
                this.on_progress && this.on_progress(Math.min(progress, 1));
            }
        });
    }

    isLoaded(name){
        return this.loadedList.indexOf(name || '') > -1;
    }
}