export const HS_LOCAL_DATAS = {

    /**普通Banner广告位 */
    adunit_banner: '',

    /**原生Banner广告位 */
    adunit_native_banner: '',

    /**激励视频广告位 */
    adunit_video: '',

    /**原生广告位 */
    adunit_native: '',

    /**普通插屏广告位 */
    adunit_intestital: '',

    /**原生插屏广告位 */
    adunit_native_intestital: '',

    /**原生icon广告位，可与原生横幅/原生Banner相同 */
    adunit_native_icon: '',

    /**九宫格广告位 */
    adunit_portal: '',

    /**互推盒子 */
    adunit_game_banner: ''
}