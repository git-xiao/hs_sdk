import BaseUserData from "./base/BaseUserData";
import Utils from "./Utils";

export default class UserData extends BaseUserData {
    static selectLevel = 1;


}