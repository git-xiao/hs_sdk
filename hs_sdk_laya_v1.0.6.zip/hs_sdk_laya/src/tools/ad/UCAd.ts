
import hs_ui_watch_video from "../../hs_ui/hs_ui_watch_video";
import GameSys from "../game_sys/GameSys";
import Utils from "../Utils";
import AdManager from "./AdManager";

export default class UCAd extends AdManager {
    
    static getInstance():UCAd {
        if (this.instance == null) {
            this.instance = new UCAd();
        }
        return this.instance;
    }

    initAd() {
        if (this.isInitAd) return;
        this.isInitAd = true;

        this.isGameCd = GameSys.adInfo.bannerDelay > 0;

        super.initAd();

        this._gameCd();
        this.initBanner();
        this.initNormalBanner();
        this.initVideo();
    }

    private _gameCd() {
        setTimeout(() => {
            this.isGameCd = false;
            if (this.isNeedShowBanner) {
                this.showBanner();
            }
        }, GameSys.adInfo.bannerDelay * 1000);
    }

    /**
     * 初始化普通banner
     */
    initNormalBanner() {
        if (GameSys.adInfo.adunit_banner.length <= 0) return;

        this.destroyNormalBanner();

        this.bannerAd = uc.createBannerAd({
            style: {
                gravity: 7, // 0:左上 1：顶部居中 2：右上
                // 3：左边垂直居中 4：居中 5：右边垂直居中
                // 6：左下 7：底部居中 8：右下 （默认为0） 
                width: GameSys.screenWidth,
                height: 0,//如果不设置高度，会按比例适配
            }
        })

        this.bannerAd.onError(err=>{
            console.error('[hs_game]normal banner error: ', JSON.stringify(err));
        });
    }

    /**
     * 展示普通banner
     */
    showNormalBanner() {
        if (this.bannerAd == null) {
            this.initNormalBanner();
        }
        if (this.bannerAd == null) return;

        this.bannerAd.show();
    }

    /**
     * 隐藏普通banner
     */
    hideNormalBanner() {
        if (this.bannerAd) {
            this.bannerAd.hide();
        }
    }

    /**
     * 销毁普通banner
     */
    destroyNormalBanner() {
        if (this.bannerAd) {
            this.bannerAd.destroy();
        }
        this.bannerAd = null;
    }

    initBanner() {
    }

    showBanner() {
        if (this.isGameCd) {
            this.isNeedShowBanner = true;
            return console.log("%c[hs_game]showBanner 广告CD中", "color: #33ccff");
        }

        this.hideBanner();
        
        this.showNormalBanner();

    }

    hideBanner() {
        super.hideBanner();
        
        this.isNeedShowBanner = false;

        this.hideNormalBanner();
    }

    initVideo() {
        if (GameSys.adInfo.adunit_video == null) return;
        this.destroyVideo();
        this.videoAd = uc.createRewardVideoAd();

        this.videoAd.onLoad(function () {
            console.log("%c[hs_game]video load succ", "color: #33ccff");
        });

        this.videoAd.onError(function (err) {
            console.log("%c[hs_game]video error: " + JSON.stringify(err), "color: red");
        });

        this.videoAd.onClose(res => {
            if (res && res.isEnded) {
                this.videocallback && this.videocallback(true);
            } else {
                (new hs_ui_watch_video()).show(()=>{
                    this.showVideo(this.videocallback);
                })
            }
            this.videoAd.load();
        });

        this.videoAd.load();
    }

    showVideo(complete?: (res: boolean) => void) {

        if (this.videoAd == null) {
            this.initVideo();
        }

        if (this.videoAd == null) {
            complete && complete(true);
            return;
        }

        this.videocallback = complete;

        this.videoAd.show().then().catch(() => {
            this.createToast('暂无视频，请稍后再试');
        })

    }

    destroyVideo() {
        if (this.videoAd) {
            this.videoAd.offLoad();
            this.videoAd.offError();
            this.videoAd.offClose();
        }
        this.videoAd = null;
    }

    showInterstitialNative(parent, on_click?: () => void, on_show?: () => void, on_hide?: () => void) {
        if (this.isGameCd || GameSys.isShieldArea) {
            this.showBanner();
            on_hide && on_hide();
            return console.log("%c[hs_game]广告CD中", "color: #33ccff");
        }
       
        this.showBanner();
        on_hide && on_hide();
    }

    /**普通插屏 */
    showInterstitial(on_show?: () => void, on_close?: () => void) {
        
        if (Utils.randomInt(1, 100) > GameSys.adInfo.showInteNormalRto) return on_close && on_close();

        this.destroyNormalInter();

        this.interAd = uc.createInterstitialAd();

        this.interAd.onLoad(() => {
            console.log("插屏广告加载");

            on_show && on_show();
        });

        this.interAd.onError(err => {
            console.log("show inter err" + JSON.stringify(err));
        })

        this.interAd.onClose(() => {
            on_close && on_close();
        })

        this.interAd.load().then(res => {
            this.interAd.show().then(()=>{
                this.hideBanner();
                
                this.interShowTime = this.get_time();
            });
        })
    }

    destroyNormalInter() {
        if (this.interAd) {
            this.interAd.offLoad();
            this.interAd.offError();
        }
        this.interAd = null;
    }

    
    /**
     * 原生插屏
     * @param on_show 成功展示回调 
     * @param on_hide 隐藏回调
     * @param on_fail 
     * @returns 
     */
     showNativeInterstitial(on_show?: () => void, on_hide?: () => void) {
        if (this.get_time() - this.interShowTime <= GameSys.adInfo.interTick * 1000) return on_hide && on_hide();

        setTimeout(()=>{
            this.hideNativeInterstitial();

            this.showInterstitial(on_show, on_hide);
            
        }, (GameSys.isShenHe || GameSys.isShieldArea) ? 0 : 1000)
    }

    login(on_succ?: (res) => void, on_fail?: (err) => void) {
        if (this.platformVersion() >= 1040) {
            uc.login({
                success: res=>{
                    on_succ && on_succ(res);
                },
                fail: (err)=>{
                    on_fail && on_fail(err);
                }
            })
        }
    }

}
