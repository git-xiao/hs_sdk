import hs_ui_share_rcorder from "../../hs_ui/hs_ui_share_rcorder";
import hs_ui_watch_video from "../../hs_ui/hs_ui_watch_video";
import GameSys from "../game_sys/GameSys";
import AdManager, { RECORDER_STATE } from "./AdManager";

export default class BaiduAd extends AdManager {
    
    recorderTime = 0;
    onRecoderStop = null;
    shareRcorderLayer: any;

    static getInstance(): BaiduAd {
        if (this.instance == null) {
            this.instance = new BaiduAd();
        }
        return this.instance;
    }

    initAd() {
        if (this.isInitAd) return;
        this.isInitAd = true;

        this.isGameCd = GameSys.adInfo.bannerDelay > 0;

        super.initAd();

        this._gameCd();
        this.initBanner();
        this.initNormalBanner();
        this.initVideo();
        this.initRecorder();
    }

    private _gameCd() {
        setTimeout(() => {
            this.isGameCd = false;
            if (this.isNeedShowBanner) {
                this.showBanner();
            }
        }, GameSys.adInfo.bannerDelay * 1000);
    }

    /**
     * 初始化普通banner
     */
    initNormalBanner() {
        if (GameSys.adInfo.adunit_banner.length <= 0) return;

        this.destroyNormalBanner();

        this.bannerAd = swan.createBannerAd({
            adUnitId: GameSys.adInfo.adunit_banner[0],
            appSid: GameSys.adInfo.adunit_appid,
            style: {
                top: GameSys.screenHeight,
                left: 0,
                width: GameSys.screenWidth
            }
        })

        this.bannerAd.onResize(res => {
            console.log(' banner 广告位宽度变化');

            this.bannerAd.style.top = GameSys.screenHeight - res.heiht;
            this.bannerAd.style.left = (GameSys.screenWidth - res.width) / 2;
        })

        this.bannerAd.onError(err=>{
            console.error('[hs_game]normal banner error: ', JSON.stringify(err));
        });
    }

    /**
     * 展示普通banner
     */
    showNormalBanner() {
        if (this.bannerAd == null) {
            this.initNormalBanner();
        }
        if (this.bannerAd == null) return;

        this.bannerAd.show().then(()=>{
            console.log("%c[hs_game]normal banner show success", "color: #33ccff");
        });
    }

    /**
     * 隐藏普通banner
     */
    hideNormalBanner() {
        if (this.bannerAd) {
            this.bannerAd.hide();
        }
    }

    /**
     * 销毁普通banner
     */
    destroyNormalBanner() {
        if (this.bannerAd) {
            this.bannerAd.destroy();
        }
        this.bannerAd = null;
    }

    initBanner() {
    }

    showBanner() {
        if (this.isGameCd) {
            this.isNeedShowBanner = true;
            return console.log("%c[hs_game]showBanner 广告CD中", "color: #33ccff");
        }

        this.hideBanner();
        
        this.showNormalBanner();

    }

    hideBanner() {
        super.hideBanner();
        this.isNeedShowBanner = false;

        this.hideNormalBanner();
    }

    initVideo() {
        if (GameSys.adInfo.adunit_video == null) return;
        this.destroyVideo();
        this.videoAd = swan.createRewardedVideoAd({
            adUnitId: GameSys.adInfo.adunit_video,
            appSid: GameSys.adInfo.adunit_appid
        });

        this.videoAd.onLoad(function () {
            console.log("%c[hs_game]video load succ", "color: #33ccff");
        });

        this.videoAd.onError(function (err) {
            console.log("%c[hs_game]video error: " + JSON.stringify(err), "color: red");
        });

        this.videoAd.onClose(res => {
            if (res && res.isEnded) {
                this.videocallback && this.videocallback(true);
            } else {
                (new hs_ui_watch_video()).show(()=>{
                    this.showVideo(this.videocallback);
                })
            }
            this.recorderResume();
            this.videoAd.load();
        });

        this.videoAd.load();
    }

    showVideo(complete?: (res: boolean) => void) {

        if (this.videoAd == null) {
            this.initVideo();
        }

        if (this.videoAd == null) {
            complete && complete(true);
            return;
        }

        this.videocallback = complete;

        this.videoAd.show().then(() => {
            this.recorderPause();
        }).catch(() => {
            this.createToast('暂无视频，请稍后再试');
        })

    }

    destroyVideo() {
        if (this.videoAd) {
            this.videoAd.offLoad();
            this.videoAd.offError();
            this.videoAd.offClose();
        }
        this.videoAd = null;
    }

    showInterstitialNative(parent, on_click?: () => void, on_show?: () => void, on_hide?: () => void) {
        if (this.isGameCd || GameSys.isShieldArea) {
            this.showBanner();
            on_hide && on_hide();
            return console.log("%c[hs_game]广告CD中", "color: #33ccff");
        }
       
        this.showBanner();
        on_hide && on_hide();
    }

    login(on_succ?: (res) => void, on_fail?: (err) => void) {
        if (this.platformVersion() >= 1040) {
            swan.login({
                success: res=>{
                    on_succ && on_succ(res);
                },
                fail: (err)=>{
                    on_fail && on_fail(err);
                }
            })
        }
    }

    private initRecorder() {
        this.gameRecorder = swan.getVideoRecorderManager();

        // 设置录屏相关监听
        this.gameRecorder.onStart(res => {
            console.log('录制开始', JSON.stringify(res));
            this.gameRecorderState = RECORDER_STATE.START;
            this.recorderTime = this.get_time();
            this.videoPath = null;
        })

        // 监听录屏过程中的错误，需根据错误码处理对应逻辑
        this.gameRecorder.onError(err => {
            console.log('录制出错', JSON.stringify(err));
            this.gameRecorderState = RECORDER_STATE.NO;
        })

        // stop 事件的回调函数
        this.gameRecorder.onStop(res => {
            this.gameRecorderState = RECORDER_STATE.STOP;
            this.videoPath = null;
            if (res && res.videoPath) {
                if (this.get_time() - this.recorderTime >= 15 * 1000) {
                    this.videoPath = res.videoPath;
                    console.log(`录屏停止，录制成功。videoID is ${res.videoPath}`)
                } else {
                    console.log(`录屏停止，录制失败。录屏时间<15s`)
                }
            } else {
                console.log(`录屏停止，录制失败`)
            }

            this.onRecoderStop && this.onRecoderStop(this.videoPath != null);
        })

        // pause 事件的回调函数
        this.gameRecorder.onPause(() => {
            console.log('暂停录制')
            this.gameRecorderState = RECORDER_STATE.PAUSE;
        })

        // resume 事件的回调函数
        this.gameRecorder.onResume(() => {
            console.log('继续录制')
            this.gameRecorderState = RECORDER_STATE.RESUME;
        })
    }

    private recorderPause() {
        if (this.gameRecorder && this.gameRecorderState == RECORDER_STATE.START) {
            this.gameRecorder.pause();
        }
    }
    
    private recorderResume() {
        if (this.gameRecorder && this.gameRecorderState == RECORDER_STATE.PAUSE) {
            this.gameRecorder.resume();
        }
    }

    recorderStart() {
        if (this.gameRecorder && this.gameRecorderState == RECORDER_STATE.NO) {
            this.gameRecorder && this.gameRecorder.start({
                duration: 120
            });
        }
    }

    recorderStop(on_stop?:(ret)=>void) {
        if (this.gameRecorder && this.gameRecorderState != RECORDER_STATE.NO) {
            this.onRecoderStop = on_stop;
            this.gameRecorder && this.gameRecorder.stop();
        }
    }

    shareRecorder(on_succ?: () => void, on_fail?: () => void) {
        if (this.gameRecorder == null || this.videoPath == null) return on_fail && on_fail();

        swan.shareVideo({
            videoPath: this.videoPath,
            success: () => {
                console.log("分享视频成功");
                on_succ && on_succ();
            },
            fail: res => {
                console.log("分享视频失败", res);
                on_fail && on_fail();
            }
        });
    }

    showRecorderLayer(on_succ?:()=>void, on_fail?:()=>void) {
        if (!this.shareRcorderLayer || this.shareRcorderLayer.destroyed) {
            this.shareRcorderLayer = new hs_ui_share_rcorder()
            this.shareRcorderLayer.show(on_succ, on_fail);
        }
    }
}