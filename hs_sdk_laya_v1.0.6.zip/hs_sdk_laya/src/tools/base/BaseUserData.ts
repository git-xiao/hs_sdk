import { EVENT_TYPE } from "../enum/Enum";
import Util from "../Utils";

export default class BaseUserData {

    /**金币 */
    static set coin(coin: number) {
        Util.setItem('COIN', coin);
        Util.emit(EVENT_TYPE.CHANGE_COIN);
    }

    static get coin() {
        return Util.getItem('COIN', 0);
    }

    /**体力 */
    static set power(power: number) {
        Util.setItem('POWER', power);
    }

    static get power() {
        return Util.getItem('POWER', 10);
    }

    static set powerTime(time: number) {
        Util.setItem('POWERTIME', time);
    }

    static get powerTime() {
        return Util.getItem('POWERTIME', 0);
    }

    /**已完成最大关卡 */
    static set maxLevel(lv: number) {
        Util.setItem('MAXLEVEL', lv);
    }

    static get maxLevel(): number {
        return Util.getItem('MAXLEVEL', 0);
    }

    /**签到时间 */
    static set signDay(day: number) {
        Util.setItem('SIGNDAY', day);
    }

    static get signDay() {
        return Util.getItem('SIGNDAY', 0);
    }

    /**签到次数 */
    static set signNum(num: number) {
        Util.setItem('SIGNNUM', num);
    }

    static get signNum() {
        return Util.getItem('SIGNNUM', 0);
    }

    /**皮肤信息 */
    static set skinInfo(info) {
        Util.setItem('SKININFO', info);
    }

    static get skinInfo() {
        return Util.getItem('SKININFO', {});
    }

    /**当前使用皮肤 */
    static set curSkinUsed(type) {
        Util.setItem('CURSKINUSED', type);
    }

    static get curSkinUsed() {
        return Util.getItem('CURSKINUSED', null);
    }

    /**背景音乐是否可播放 */
    static set musicPlay(type) {
        Util.setItem('MUSIC', type);
    }

    static get musicPlay() {
        return Util.getItem('MUSIC', true);
    }

    /**音效是否可播放 */
    static set soundPlay(type) {
        Util.setItem('SOUND', type);
    }

    static get soundPlay() {
        return Util.getItem('SOUND', true);
    }

    /**是否可震动 */
    static set vibrate(type) {
        Util.setItem('VIBRATE', type);
    }

    static get vibrate() {
        return Util.getItem('VIBRATE', true);
    }

    /**是否新玩家 */
    static set isNewPlay(newPlay: boolean) {
        Util.setItem('NEWPLAY', newPlay);
    }

    static get isNewPlay() {
        return Util.getItem('NEWPLAY', true);
    }

    /**
     * 随机生成用户UUID
     */
    static get uid() {
        let uid = Util.getItem('UUID', null);
        if (uid == null) {
            let d = new Date().getTime();
            uid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                let r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });

            Util.setItem('UUID', uid);
        }
        return uid;
    }
}