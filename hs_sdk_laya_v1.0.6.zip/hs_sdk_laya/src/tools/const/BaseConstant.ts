
export default class BaseConstant {

	/**请求地址 */
	static readonly BASE_URL = "https://gamesdata.hongshunet.com:8443/";

	/**是否原生平台 */
	static readonly IS_IOS = window['conchConfig'] && window['conchConfig'].getOS() == "Conch-ios";
	
	static readonly IS_ANDROID = window['conchConfig'] && window['conchConfig'].getOS() == "Conch-android";

	/**微信小游戏 */
	static readonly IS_WECHAT_GAME = (Laya.Browser.onMiniGame || typeof window['wxMiniGame'] != 'undefined') && typeof window['ks'] != 'undefined';

	/**QQ小游戏 */
	static readonly IS_QQ_GAME = Laya.Browser.onQQMiniGame || typeof window['qq'] != 'undefined';

	/**OPPO小游戏 */
	static readonly IS_OPPO_GAME = Laya.Browser.onQGMiniGame || typeof window['qg'] != 'undefined' && window['qg'].getProvider() == 'OPPO';

	/**VIVO小游戏 */
	static readonly IS_VIVO_GAME = Laya.Browser.onVVMiniGame || typeof window['qg'] != 'undefined' && window['qg'].getProvider() == 'vivo';

	/**百度小游戏 */
	static readonly IS_BAIDU_GAME = Laya.Browser.onBDMiniGame || typeof window['swan'] != 'undefined';

	/**字节小游戏 */
	static readonly IS_BYTEDANCE_GAME = Laya.Browser.onTTMiniGame || typeof window['tt'] != 'undefined';

	/**华为小游戏 */
	static readonly IS_HUAWEI_GAME = Laya.Browser.onHWMiniGame || typeof window['hbs'] != 'undefined';

	/**魅族小游戏 */
	static readonly IS_MEIZU_GAME = typeof window['mz_jsb'] != 'undefined';

	/**UC小游戏 */
	static readonly IS_UC_GAME = typeof window['uc'] != 'undefined';
	
	/**快手小游戏 */
	static readonly IS_KS_GAME = typeof window['ks'] != 'undefined';

	static get IS_WEB_GAME() {
		let ret = true;
		if (this.IS_IOS || this.IS_ANDROID) return false;
		for (let name in this) {
			if (name.search(/IS_.*?_GAME$/i) >= 0) {
				ret = ret && !this[name];
			}
			if (!ret) return ret;
		}
		return ret;
	}

	static get PLATFORM_CODE() {
		let code = 0;
		if (this.IS_WECHAT_GAME) {
			code = 1;
		} else if (this.IS_QQ_GAME) {
			code = 2;
		} else if (this.IS_OPPO_GAME) {
			code = 3;
		} else if (this.IS_VIVO_GAME) {
			code = 4;
		} else if (this.IS_BAIDU_GAME) {
			code = 5;
		} else if (this.IS_BYTEDANCE_GAME) {
			code = 6;
		} else if (this.IS_HUAWEI_GAME) {
			code = 7;
		} else if (this.IS_MEIZU_GAME) {
			code = 8;
		} else if (this.IS_UC_GAME) {
			code = 9;
		}
		return code;
	}

}
