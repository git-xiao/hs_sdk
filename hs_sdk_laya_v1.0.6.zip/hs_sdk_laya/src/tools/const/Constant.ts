
import { e_sdk_type } from "../enum/Enum";
import BaseConstant from "./BaseConstant";

export default class Constant extends BaseConstant {

	/**
	 * 后台游戏id
	 * 用于请求后台配置
	 */
	static readonly GID = 0;
	/**
	 * 后台游戏名
	 * 用于请求后台配置
	 */
	static readonly PROGECT_NAME = '';
	/**
	 * 后台游戏版本号
	 * 用于请求后台配置
	 * 微信 1.x.x;头条 2.x.x;百度 3.x.x;QQ 4.x.x;OPPO 5.x.x;vivo 6.x.x;趣头条 7.x.x;梦工厂 8.x.x;UC 9.x.x;魅族 10.x.x
	 */
	static readonly GAME_VERSION_NAME = '6.0.1';

	/**热云AppKey */
	static readonly APPID = '';

	/**友盟AppKey */
	static readonly YM_APPID = '';

	/**SDK */
	static SDK_TYPE = e_sdk_type.HS;

	/**总关卡数 */
	static readonly TOTAL_LEVEL = 35;

	static readonly SOUND = {
		CLICK: 'sounds/click.mp3',
		BG: 'sounds/bgm.mp3',
	}
	
	/**
	 * 分包
	 * 优先级表示加载顺序，>= 5 表示无需等待加载完成
	*/
	static readonly subpackage = [
		{ name: 'res3d', priority: 0 },
		{ name: 'skin_mat', priority: 5 }
	];
}