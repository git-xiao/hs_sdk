// v1.2.6
//是否使用IDE自带的node环境和插件，设置false后，则使用自己环境(使用命令行方式执行)
const useIDENode = process.argv[0].indexOf("LayaAir") > -1 ? true : false;
const useCMDNode = process.argv[1].indexOf("layaair2-cmd") > -1 ? true : false;

function useOtherNode(){
	return useIDENode||useCMDNode;
}
const workSpaceDir = useOtherNode() ? process.argv[2].replace("--gulpfile=", "").replace("\\.laya\\publish.js", "").replace("/.laya/publish.js", "") + "/" : "./../";

const gulp = require(ideModuleDir + "gulp");
const path = require('path');
const fs = require('fs');


if (!useOtherNode() && process.argv.length > 5 && process.argv[4] == "--config") {
	platform = process.argv[5].replace(".json", "");
}
if (useOtherNode() && process.argv.length >= 4 && process.argv[3].startsWith("--config") && process.argv[3].endsWith(".json")) {
	platform = process.argv[3].match(/(\w+).json/)[1];
}

let con_bck = `
var uma = null;
if (window['qg']) {
	window['qg'].uma = uma;
}
if (window['wx']) {
	window['wx'].uma = uma;
}
if (window['tt']) {
	window['tt'].uma = uma;
}
if (window['swan']) {
	window['swan'].uma = uma;
}
if (window['qq']) {
	window['qq'].uma = uma;
}
export default uma;
`;

// 替换对应平台友盟
gulp.task("replaceUMA", function () {
	let url;
	
	if (platform === "oppogame" || platform === "vivogame") {
		url = path.join(workSpaceDir, "uma", "oppogame", "uma.min.js");
	} else {
		url = path.join(workSpaceDir, "uma", platform, "uma.min.js");
	}

	let uma_url = path.join(workSpaceDir, "src", "tools", "uma.min.js");
	if (fs.existsSync(url)) {
		let con = fs.readFileSync(url, "utf8");
		con_bck = fs.readFileSync(uma_url, "utf8");

		fs.writeFileSync(uma_url, con, "utf-8");
	} else {
		console.warn(`[${platform}]友盟文件不存在，使用默认文件。`);
	}
});

// 创建分包入口文件
gulp.task("copyCustomFile", ["copyLibsJsFile"], function () {
    const config = global.config;
    const releaseDir = global.releaseDir;

	let uma_url = path.join(workSpaceDir, "src", "tools", "uma.min.js");
	fs.writeFileSync(uma_url, con_bck, "utf-8");

	// 分包
	let is_subpack = false;
	let subpack_list = [];
	let file_name = '';
	if (platform === "oppogame") {
		is_subpack = config.oppoInfo.subpack;
		subpack_list = config.oppoSubpack;
		file_name = 'main.js';
	} else if (platform === "vivogame") {
		is_subpack = config.vivoInfo.subpack;
		subpack_list = config.vivoSubpack;
		file_name = 'game.js';
	} else if (platform === "bytedancegame") {
		is_subpack = config.bytedanceInfo.subpack;
		subpack_list = config.bytedanceSubpack;
		file_name = 'game.js';
	}

	if (is_subpack && subpack_list.length > 0) {
		subpack_list.forEach(pack => {
			let dest = path.join(releaseDir, `${pack.root}${file_name}`);
			if (!fs.existsSync(dest)) {
				fs.writeFileSync(dest, `console.log('[${pack.name}]分包入口');`, "utf8");
			}

			let url = `!${releaseDir}/${pack.root}${file_name}`;
			if (config.version && config.versionFilter.indexOf(url) == -1) {
				config.versionFilter.push(url);
			}
		});
	}
});